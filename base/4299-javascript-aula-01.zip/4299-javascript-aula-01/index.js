const inputItem = document.getElementById("input-item")

console.log(inputItem.value);
